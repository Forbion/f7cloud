{
	year: {
		past: "{0} tahun yang lalu",
		future: "dalam {0} tahun"
	},
	month: {
		past: "{0} bulan yang lalu",
		future: "dalam {0} bulan"
	},
	week: {
		past: "{0} minggu yang lalu",
		future: "dalam {0} minggu"
	},
	day: {
		past: "{0} hari yang lalu",
		future: "dalam {0} hari"
	},
	hour: {
		past: "{0} jam yang lalu",
		future: "dalam {0} jam"
	},
	minute: {
		past: "{0} menit yang lalu",
		future: "dalam {0} menit"
	},
	second: {
		past: "{0} detik yang lalu",
		future: "dalam {0} detik"
	},
	plural: n => 1 == n ? 'one' : 'other'
}
