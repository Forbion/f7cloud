<?php

namespace RainLoop\Enumerations;

abstract class Layout
{
	const NO_PREVIEW = 0;
	const SIDE_PREVIEW = 1;
	const BOTTOM_PREVIEW = 2;
}
