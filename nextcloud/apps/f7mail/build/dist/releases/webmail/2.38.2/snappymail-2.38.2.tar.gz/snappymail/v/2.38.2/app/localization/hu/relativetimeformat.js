{
	long: {
		year: {
			past: "{0} évvel ezelőtt",
			future: "{0} év múlva"
		},
		month: {
			past: "{0} hónappal ezelőtt",
			future: "{0} hónap múlva"
		},
		week: {
			past: "{0} héttel ezelőtt",
			future: "{0} hét múlva"
		},
		day: {
			past: "{0} nappal ezelőtt",
			future: "{0} nap múlva"
		},
		hour: {
			past: "{0} órával ezelőtt",
			future: "{0} óra múlva"
		},
		minute: {
			past: "{0} perccel ezelőtt",
			future: "{0} perc múlva"
		},
		second: {
			past: "{0} másodperccel ezelőtt",
			future: "{0} másodperc múlva"
		}
	}
}
