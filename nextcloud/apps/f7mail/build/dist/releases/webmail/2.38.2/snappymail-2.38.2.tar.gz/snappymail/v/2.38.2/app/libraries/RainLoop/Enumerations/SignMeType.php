<?php

namespace RainLoop\Enumerations;

abstract class SignMeType
{
	const DefaultOff = 'DefaultOff';
	const DefaultOn = 'DefaultOn';
	const Unused = 'Unused';
}
