{
	year: {
		past: "{0} سال پیش",
		future: "{0} سال بعد"
	},
	month: {
		past: "{0} ماه پیش",
		future: "{0} ماه بعد"
	},
	week: {
		past: "{0} هفته پیش",
		future: "{0} هفته بعد"
	},
	day: {
		past: "{0} روز پیش",
		future: "{0} روز بعد"
	},
	hour: {
		past: "{0} ساعت پیش",
		future: "{0} ساعت بعد"
	},
	minute: {
		past: "{0} دقیقه پیش",
		future: "{0} دقیقه بعد"
	},
	second: {
		past: "{0} ثانیه پیش",
		future: "{0} ثانیه بعد"
	},
	plural: n => 1 == n ? 'one' : 'other'
}
